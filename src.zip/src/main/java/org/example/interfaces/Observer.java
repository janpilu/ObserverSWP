package org.example.interfaces;

public interface Observer {
    public void refresh();
}
